"""Watchtower Link USB helper: no Python setup in the packaged Windows EXE.

ADB reverse forwards only Link's control/evidence/relay API to the selected
platform. It never changes global phone proxies, Wi-Fi or other apps.
"""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
import argparse, base64, hashlib, hmac, json, os, signal, subprocess, sys, threading, time, shutil, secrets

BASE=Path(sys.executable).parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
PORT=17864
ALLOWED={'handshake','poll','result','traffic','capture','relay','ca','certificate','fiber_version','fiber_download'}

def adb_path():
    candidates=([BASE/'tools/adb.exe',BASE/'adb.exe'] if os.name=='nt' else [BASE/'tools/linux/adb',BASE/'tools/adb',BASE/'adb'])
    if os.name!='nt' and shutil.which('adb'):candidates.append(Path(shutil.which('adb')))
    return next((p for p in candidates if p.is_file()), None)

class Bridge:
    def __init__(self, config, adb=None):
        self.config=config
        url=config['platform_url'].strip().rstrip('/')
        if not url.startswith(('http://','https://')): url='http://'+url
        parts=urlsplit(url)
        if parts.scheme not in ('http','https') or not parts.hostname or parts.username or parts.password or parts.path not in ('','/') or parts.query or parts.fragment:
            raise ValueError('Invalid platform URL')
        self.url=url
        self.adb=Path(adb) if adb else adb_path()
        if not self.adb: raise ValueError('Bundled ADB is missing')
        self.serial=None;self.owned_reverse=False;self.started=False;self.transport='usb'
        self.stopping=threading.Event();self.status='Ready / 就绪'
        self.server=None
    def run_adb(self,*args,timeout=20):
        command=[str(self.adb)]+(['-s',self.serial] if self.serial else [])+list(args)
        try:
            p=subprocess.run(command,capture_output=True,timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        except subprocess.TimeoutExpired:
            raise ValueError('Phone operation timed out; check the confirmation on the phone / 操作超时，请检查手机上的确认提示') from None
        if p.returncode:
            detail=(p.stderr+p.stdout).decode('utf-8','replace')
            if self.serial:detail=detail.replace(self.serial,'[device]')
            if 'User rejected permissions' in detail or 'INSTALL_FAILED_ABORTED' in detail:
                raise ValueError('Android declined the Link update; allow installation on the phone and retry / 手机拒绝了Link更新，请在手机允许安装后重试')
            if 'INSTALL_FAILED_UPDATE_INCOMPATIBLE' in detail:
                raise ValueError('Link installation signature differs; existing app data was preserved / Link安装签名不一致，原应用数据已保留')
            raise ValueError('ADB failed: '+detail[-250:])
        return p.stdout.decode('utf-8','replace')
    def install_link(self,apk):
        # A fixed ASCII remote directory also works when the local installation
        # contains Chinese characters. Android still owns installation consent.
        remote='/data/local/tmp/watchtower-link-'+secrets.token_hex(8)+'.apk'
        self.status='Installing Link; check the phone confirmation / 正在更新Link，请查看手机确认'
        try:
            self.run_adb('push',str(apk),remote,timeout=45)
            result=self.run_adb('shell','pm','install','-r',remote,timeout=120)
            if 'Success' not in result:
                if 'User rejected permissions' in result or 'INSTALL_FAILED_ABORTED' in result:
                    raise ValueError('Android declined the Link update; allow installation on the phone and retry / 手机拒绝了Link更新，请在手机允许安装后重试')
                if 'INSTALL_FAILED_UPDATE_INCOMPATIBLE' in result:
                    raise ValueError('Link installation signature differs; existing app data was preserved / Link安装签名不一致，原应用数据已保留')
                raise ValueError('Link update failed; existing app data was preserved / Link更新失败，原应用数据已保留')
        finally:
            try:self.run_adb('shell','rm','-f',remote)
            except ValueError:pass
    def devices(self):
        text=self.run_adb('devices')
        return [(p[0],p[1]) for line in text.splitlines() if len(p:=line.split())>=2 and p[1] in ('device','unauthorized','offline')]
    def start(self, host='127.0.0.1', port=PORT):
        bridge=self
        class Handler(BaseHTTPRequestHandler):
            protocol_version='HTTP/1.1'
            def log_message(self,*args): pass
            def proxy(self):
                part=urlsplit(self.path)
                name=part.path.removeprefix('/api/appbridge/')
                if not part.path.startswith('/api/appbridge/') or name not in ALLOWED or part.scheme or part.netloc:
                    self.send_error(404);return
                try:
                    size=int(self.headers.get('Content-Length',0))
                    if not 0<=size<=1200000: raise ValueError('Request too large')
                    body=self.rfile.read(size) if size else None
                    key=self.headers.get('X-Platform-Key','')
                    if not hmac.compare_digest(key,bridge.config['platform_key']):
                        self.send_error(403);return
                    req=Request(bridge.url+self.path,data=body,method=self.command,
                        headers={'X-Platform-Key':key,'Content-Type':'application/json','X-App-Platform-Url':self.headers.get('X-App-Platform-Url',''),'X-App-Version-Code':self.headers.get('X-App-Version-Code','')})
                    try: response=urlopen(req,timeout=45)
                    except HTTPError as e: response=e
                    with response:
                        data=response.read(16000000)
                        self.send_response(response.status)
                        self.send_header('Content-Type',response.headers.get('Content-Type','application/json'))
                        self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
                except Exception:
                    data=json.dumps({'code':503,'message':'USB bridge cannot reach platform','data':{}}).encode()
                    try:
                        self.send_response(503);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(data)));self.end_headers();self.wfile.write(data)
                    except OSError:pass
            do_GET=proxy
            do_POST=proxy
        self.server=ThreadingHTTPServer((host,port),Handler);self.server.daemon_threads=True
        threading.Thread(target=self.server.serve_forever,daemon=True,name='link-usb-http').start()
    def connect(self,serial=None,transport='usb',egress=None,target='',install=True):
        devs=self.devices()
        ready=[d for d,state in devs if state=='device']
        if serial and serial not in ready: raise ValueError('Selected device is not authorized / 请授权USB调试')
        if not serial:
            if len(ready)!=1: raise ValueError('Need exactly one authorized USB device, or choose a device / 请连接并授权一台手机')
            serial=ready[0]
        self.serial=serial;self.transport=transport
        if egress is not None and egress not in ('direct','platform'): raise ValueError('Invalid egress option')
        if not install and egress is None:
            import re
            version=re.search(r'versionCode=(\d+)',self.run_adb('shell','dumpsys','package','com.watchtower.fiber'))
            if version is None or int(version.group(1))<7: raise ValueError('Update Link App before connecting / 请先更新Link APP')
        if transport=='usb':
            mappings=self.run_adb('reverse','--list')
            present=[x.split() for x in mappings.splitlines() if 'tcp:'+str(PORT) in x.split()]
            if present and any(x[-2:]!=['tcp:'+str(PORT),'tcp:'+str(PORT)] for x in present):
                raise ValueError('Device port is already used by another tool')
            self.run_adb('reverse','tcp:'+str(PORT),'tcp:'+str(PORT))
            self.owned_reverse=not bool(present)
        if install:
            apk=BASE/'Watchtower-Link.apk'
            if not apk.is_file(): raise ValueError('Configured APK is missing')
            self.install_link(apk)
        options={'transport':transport,'target':target,'platform_url':self.config['platform_url'],
            'action':'capture' if target else 'connect','issued':int(time.time())}
        if egress is not None: options['egress']=egress
        payload=base64.b64encode(json.dumps(options,separators=(',',':')).encode()).decode()
        sig=hmac.new(self.config['platform_key'].encode(),payload.encode(),hashlib.sha256).hexdigest()
        self.run_adb('shell','am','start','-n','com.watchtower.fiber/.MainActivity','--es','link_request',payload,'--es','link_signature',sig)
        self.started=True;self.status='Connected / 已连接；请在手机选择App并批准VPN'
        threading.Thread(target=self.monitor,daemon=True).start()
    def monitor(self):
        while not self.stopping.wait(2):
            try:
                if (self.serial,'device') not in self.devices(): self.status='USB disconnected / USB已断开，等待重连';continue
                if self.transport=='usb': self.run_adb('reverse','tcp:'+str(PORT),'tcp:'+str(PORT))
                self.status='Connected / 已连接'
            except Exception:self.status='Waiting for USB authorization / 等待USB调试授权'
    def close(self):
        self.stopping.set()
        if self.serial and self.transport=='usb':
            if self.started:
                try:self.run_adb('shell','am','force-stop','com.watchtower.fiber')
                except Exception:pass
            if self.owned_reverse:
                try:self.run_adb('reverse','--remove','tcp:'+str(PORT))
                except Exception:pass
        if self.server:self.server.shutdown();self.server.server_close()

def gui(bridge):
    import tkinter as tk
    from tkinter import ttk,messagebox
    root=tk.Tk();root.title('Watchtower Link · 瞭望塔流桥');root.geometry('560x420');root.configure(bg='#0b111b')
    style=ttk.Style();style.theme_use('clam');style.configure('TLabel',background='#0b111b',foreground='#e1eaf3');style.configure('TFrame',background='#0b111b')
    frame=ttk.Frame(root,padding=24);frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='Watchtower Link',font=('Segoe UI',22,'bold')).pack(anchor='w')
    ttk.Label(frame,text='USB / ADB · Selected app traffic · 指定App流量',wraplength=500).pack(anchor='w',pady=(8,18))
    ttk.Label(frame,text=bridge.url).pack(anchor='w')
    transport=tk.StringVar(value='usb');target=tk.StringVar()
    ttk.Label(frame,text='Connection / 连接方式').pack(anchor='w',pady=(12,4))
    ttk.Combobox(frame,textvariable=transport,values=['usb','wireless'],state='readonly').pack(fill='x')
    ttk.Label(frame,text='Set traffic egress in the App / 流量出口请在APP内设置').pack(anchor='w',pady=(12,4))
    status=tk.StringVar(value=bridge.status)
    def connect():
        button.configure(state='disabled')
        def work():
            try:bridge.connect(transport=transport.get(),target=target.get())
            except Exception as e:root.after(0,lambda error=str(e):messagebox.showerror('Watchtower Link',error))
            finally:root.after(0,lambda:button.configure(state='normal'))
        threading.Thread(target=work,daemon=True).start()
    button=ttk.Button(frame,text='Install & Connect / 安装并连接',command=connect);button.pack(fill='x',pady=18)
    ttk.Label(frame,textvariable=status,wraplength=500).pack(anchor='w')
    ttk.Label(frame,text='USB调试只需手机授权。选择App与VPN授权在手机完成。\n关闭此程序会停止本次USB采集，恢复目标App路由。',wraplength=500).pack(anchor='w',pady=12)
    def tick():status.set(bridge.status);root.after(1000,tick)
    tick();root.mainloop()

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',default=str(BASE/'link_config.json'));p.add_argument('--headless',action='store_true');p.add_argument('--adb');p.add_argument('--serial');p.add_argument('--transport',choices=['usb','wireless'],default='usb');p.add_argument('--egress',choices=['direct','platform'],default=None);p.add_argument('--target',default='');p.add_argument('--no-install',action='store_true')
    args=p.parse_args();args.headless=args.headless or os.name!='nt';bridge=Bridge(json.loads(Path(args.config).read_text(encoding='utf-8')),args.adb)
    try:
        bridge.start()
        if args.headless:
            bridge.connect(args.serial,args.transport,args.egress,args.target,not args.no_install)
            print('Link ready; device identity and credentials are not printed.',flush=True)
            signal.signal(signal.SIGINT,lambda *_:bridge.stopping.set());signal.signal(signal.SIGTERM,lambda *_:bridge.stopping.set())
            while not bridge.stopping.wait(1):pass
        else:gui(bridge)
    finally:bridge.close()
if __name__=='__main__':main()
