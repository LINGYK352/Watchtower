Watchtower Link / 瞭望塔流桥
连接方式选择有线/无线；流量出口与目标APP在手机APP内设置。
Windows解压后运行Watchtower-Link.exe，授权USB调试并安装/更新APP。
默认保留APP的出口与HTTPS设置；显式旧CLI --egress 参数仍可用。
关闭辅助程序停止本次连接，不修改全局手机代理/Wi-Fi设置。
