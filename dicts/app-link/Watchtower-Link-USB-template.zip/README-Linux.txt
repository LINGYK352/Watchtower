Linux x86_64: python3 link_usb.py --headless
Allow USB debugging and install/update Link App. Egress is configured in the App.
Explicit legacy --egress direct|platform remains supported.
No credentials are included in this template.
