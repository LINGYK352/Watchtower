Watchtower Maintenance Node - Linux amd64 TEST candidate
Start: ./start.sh  (or run ./Watchtower-public-node directly). No IP or domain setup.
Default: listen on 0.0.0.0:7443, authenticated forwarding and bounded encrypted cache (1024 MiB).
The process prints its TLS SHA-256 fingerprint and private administration-key FILE path, never the key.
Clients enter the reachable server IP/domain and port in their own platform and verify the fingerprint.
The default TLS identity is persistent and does not depend on an IP/domain. Restart keeps it unchanged.
State: $XDG_STATE_HOME/watchtower-node or ~/.local/state/watchtower-node. Existing packaged data/admin.key is reused.
Optional: --port 8443; --data-dir /private/state; --mode relay; --quota-mib 1024; --cert/--key.
Legacy explicit --public-host is still accepted. An explicit loopback bind keeps local HTTP compatibility.
Keep admin.key and all .key files private. Each workspace has its own scoped encrypted realm and quotas.
Allow access to the chosen TCP listener in your network policy. The program does not change firewalls.
Requires Linux x86-64/glibc >=2.31; no Python install needed. ARM/Alpine have not been tested.
Cache refuses new writes at capacity and preserves pending delivery data. This is not a forward-secrecy claim.
