#!/bin/sh
set -eu
NODE_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
umask 077
exec "$NODE_DIR/Watchtower-public-node" "$@"
